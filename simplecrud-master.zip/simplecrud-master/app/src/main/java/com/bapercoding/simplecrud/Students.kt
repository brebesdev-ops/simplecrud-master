package com.bapercoding.simplecrud

data class Students (val nim:String?,val name:String?,val address:String,val gender:String?)